ZGMINI #996 - 별도 Windows PC TEMP 한정 보안 복원 시험

주의: 기존 운영 PC에서 실행하지 마십시오.
      E:\ZGmini 경로가 있는 PC에서는 실제 Windows 시험을 자동으로 건너뜁니다.
      이 묶음은 실제 C급 복구 및 설치 패키지가 아닙니다.

1. 물리적으로 분리된 Windows 시험 PC에 이 ZIP을 다운로드합니다.
2. ZIP을 압축 해제합니다. 폴더 안에 tools, tests 두 폴더가 있어야 합니다.
3. 압축 해제한 최상위 폴더를 파일 탐색기로 엽니다.
4. 탐색기 주소창에 powershell 을 입력하고 Enter를 누릅니다.
5. 열린 PowerShell에서 다음 한 줄을 실행합니다.

   node --test .\tests\controller-996-windows-temp-security-window.test.mjs

합격 조건: tests 7, pass 7, fail 0, skipped 0.
오류 또는 skipped가 발생하면 반복 실행하지 말고 전체 출력을 전달하십시오.

이 시험은 새 TEMP 합성 파일만 만들고 복원합니다.
시험 중 원본 ZGMINI 파일, Claim, Install Lease, Workflow, Backlog는 건드리지 않습니다.
강제 종료된 자식 프로세스의 권한 복원 가능성만 시험합니다.
Windows 전체 정전 및 복원기의 동시 중단 후 자동 복원은 검증하지 않습니다.

원본 브랜치: ansqhd5774-Choi/zgmini-pc-control
codex/controller-996-intake-c-candidate-r1-20261110
소스 기준 커밋: b6712fe0e3962f4816fae19f5ab8a3cd23ed4f6c
실제 운영 #996 진행률: 80%, C 실행 NO-GO
