#996 read-only review bundle
Source: 3fa23ecb241f22d8694afd3432a1bcefe498cd9a
Operator hold is enabled. No S2 manifest, Owner approval or production entry is supplied.
