@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if errorlevel 1 goto BLOCKED
if not exist "tests\controller-996-windows-temp-security-window.test.mjs" goto BLOCKED
if not exist "tools\TEST_996_WINDOWS_TEMP_SECURITY_WINDOW.ps1" goto BLOCKED
where node.exe >nul 2>&1
if errorlevel 1 goto BLOCKED

echo ZGMINI #996 - Windows TEMP-only security fixture (not C production)
echo Original E:\ZGmini files, leases, workflows and security are NOT targets.
echo Executing three isolated TEMP checks after the four static checks.
set "ZGMINI_996_TEMP_ONLY_ON_ORIGINAL_PC=1"
node --test "tests\controller-996-windows-temp-security-window.test.mjs"
set "testExit=%ERRORLEVEL%"
echo.
echo Test exit code: %testExit%
echo Report the entire screen. Do not rerun after a failure.
pause
exit /b %testExit%

:BLOCKED
echo BLOCKED: this folder is incomplete or Node is unavailable.
echo No test was started. Do not use alternate commands.
pause
exit /b 2
