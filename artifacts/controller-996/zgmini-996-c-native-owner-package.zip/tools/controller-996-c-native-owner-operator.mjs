// #996 C-grade original Windows OWNER operator CANDIDATE.
// This file is not installed, approved or executable in the current project.
// It has no test or synthetic authorization port and never adopts the old
// C owner. Only a NEW independently read, exact Owner approval AND immutable
// local/Git bundle AND fresh original-Windows evidence can cross the write
// boundary. An interruption is STATE_UNKNOWN: no retry, rollback or cleanup.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {registerHooks,isBuiltin} from 'node:module';
import {createHash,randomUUID} from 'node:crypto';
import {execFileSync} from 'node:child_process';

const REPO='ansqhd5774-Choi/zgmini-pc-control';
const REQ='pc-update-0010b2cf-9bca-40cf-89c5-b750fa42b404';
const ROOT='E:/ZGmini';
const NODE='E:/ZGmini/runtime/node.exe';
const GH='C:/Program Files/GitHub CLI/gh.exe';
const PS='C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe';
const LEASES=ROOT+'/automation/pc-maintenance/leases';
const DIR=path.dirname(fileURLToPath(import.meta.url));
const LOCAL_LOCK=path.join(DIR,'controller-996-c-native-owner-source-lock.json');
const LOCAL_PACKAGE=path.resolve(DIR,'../artifacts/controller-996/zgmini-996-c-native-owner-package.zip');
const LOCK_REPO='tools/controller-996-c-native-owner-source-lock.json';
const PACKAGE_REPO='artifacts/controller-996/zgmini-996-c-native-owner-package.zip';
const SELF_REPO='tools/controller-996-c-native-owner-operator.mjs';
// Reviewed builtins-only verifier. Caller-supplied lock/receipt pins cannot
// replace this authentication implementation with a synthetic verifier.
const TRUSTED_BOOTSTRAP_SHA256='4827b8a14005c8b07056bec2a831f2890eae293c4561168557b9e552a5394e7d';
let sealedOwnerEntry=null; // Set only by the authenticated CLI path below.
const FILES=[
  SELF_REPO,
  'tools/controller-996-c-native-trusted-bootstrap.mjs',
  'tools/controller-996-c-installed-gh-get-readonly.mjs',
  'tools/controller-996-native-continuation-consent-reader.mjs',
  'tools/controller-996-original-four-jobs-readonly.mjs',
  'tools/controller-996-continuation-gate.mjs',
  'tools/controller-996-c-original-prewrite-readonly.mjs',
  'tools/controller-996-c-original-stage-readonly.mjs',
  'tools/controller-996-c-physical-disposition-readonly.mjs',
  'tools/controller-996-git-byte-offline-readonly-r4.mjs',
  'tools/controller-996-git-byte-offline-manifest-r4.json',
  'tools/controller-996-interrupted-observer.mjs',
  'tools/controller-996-protection-attestation.mjs',
  'tools/controller-996-r2-evidence-review.mjs',
  'tools/controller-996-windows-archive-adapter.mjs',
  'tools/controller-996-windows-observer.mjs',
];
const sha=x=>createHash('sha256').update(x).digest('hex');
const blobSHA=x=>createHash('sha1').update(Buffer.from(`blob ${x.length}\0`))
  .update(x).digest('hex');
const H40=x=>typeof x==='string'&&/^[a-f0-9]{40}$/.test(x);
const H64=x=>typeof x==='string'&&/^[a-f0-9]{64}$/.test(x);
const UUID=x=>typeof x==='string'&&
  /^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(x);
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const need=(ok,code)=>{if(!ok)throw Object.assign(Error(code),{code});};
const stop=(code,phase='NO_WRITE')=>Object.freeze({
  schema:'ZGMINI_CONTROLLER_996_NATIVE_OWNER_C_RESULT_V1',
  status:phase==='NO_WRITE'?'BLOCKED_BEFORE_C_WRITE':
    'STATE_UNKNOWN_PRESERVE_ALL_C_CLAIMS',
  code,phase,executionAuthorized:false,automaticRetry:false,
  cleanupPerformed:false,workflowPuts:0,backlogWrites:0,
  issuePosts:0,originalRequestRetries:0,
});
const safeCode=e=>/^(?:C_996_OWNER|C996_NATIVE)_[A-Z0-9_]+$/.test(e?.code??'')?
  e.code:'C_996_OWNER_STATE_UNKNOWN';
const rel=x=>typeof x==='string'&&!x.includes('\\')&&
  !path.isAbsolute(x)&&x.split('/').every(p=>p&&p!=='.'&&p!=='..');

function originalWindows(){
  need(process.platform==='win32'&&!process.env.GITHUB_ACTIONS&&
    !process.env.RUNNER_NAME&&!process.env.GH_HOST&&
    path.win32.normalize(process.execPath).toLowerCase()===
      path.win32.normalize(NODE).toLowerCase(),
  'C_996_OWNER_ORIGINAL_WINDOWS_ONLY');
}
function safeFile(full,limit){
  const st=fs.lstatSync(full);
  need(st.isFile()&&!st.isSymbolicLink()&&st.nlink===1&&
    st.size>0&&st.size<=limit,'C_996_OWNER_BUNDLE_FILE_UNSAFE');
  return fs.readFileSync(full);
}
function safeLeaseDirectory(relPath){
  need(relPath===''||rel(relPath),'C_996_OWNER_LEASE_REL_UNSAFE');
  let at=ROOT;
  for(const segment of [null,...('automation/pc-maintenance/leases'+
    (relPath?'/'+relPath:'')).split('/')]){
    if(segment!==null)at=path.join(at,segment);
    const st=fs.lstatSync(at);
    need(st.isDirectory()&&!st.isSymbolicLink(),
      'C_996_OWNER_LEASE_PARENT_REDIRECT');
  }
  return at;
}
function absent(full){
  try{fs.lstatSync(full);return false;}
  catch(e){if(e?.code==='ENOENT')return true;throw e;}
}
function writeOnce(dir,name,data){
  need(/^(?:owner|PREPARED|OLD_C_CLAIM_ARCHIVE_ATTEMPTED|READY_TO_RELEASE_INSTALL)\.json$/.test(name),
    'C_996_OWNER_MARKER_NOT_ALLOWED');
  const bytes=Buffer.from(JSON.stringify(data)+'\n');
  need(bytes.length>0&&bytes.length<=16_384,
    'C_996_OWNER_MARKER_TOO_LARGE');
  const full=path.join(dir,name),fd=fs.openSync(full,'wx',0o600);
  try{fs.writeSync(fd,bytes);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
  need(sha(safeFile(full,16_384))===sha(bytes),
    'C_996_OWNER_MARKER_READBACK_DRIFT');
  return sha(bytes);
}
// The fixture renders the same native code, restricted to designated TEMP paths.
export function build996OwnerArchiveFixtureScript(){
  return handleArchiveScript(true);
}
function handleArchiveScript(fixture=false){
  return String.raw`
$ErrorActionPreference = 'Stop'
try {
  Add-Type -AssemblyName System.Web.Extensions
  Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using Microsoft.Win32.SafeHandles;
using System.Web.Script.Serialization;

public static class C996NativeDirectory {
  static readonly bool Fixture = __FIXTURE__;
  const uint ATTR_REPARSE=0x400, ATTR_DIRECTORY=0x10;
  const uint READ_ATTRIBUTES=0x80, DELETE=0x10000, GENERIC_READ=0x80000000;
  const uint SHARE_READ=1, SHARE_WRITE=2, OPEN_EXISTING=3;
  const uint BACKUP_SEMANTICS=0x02000000, OPEN_REPARSE_POINT=0x00200000;
  [StructLayout(LayoutKind.Sequential)] struct FT {public uint Low;public uint High;}
  [StructLayout(LayoutKind.Sequential)] struct INFO {
    public uint Attr;public FT Created;public FT Accessed;public FT Written;
    public uint Volume;public uint SizeHigh;public uint SizeLow;public uint Links;
    public uint IndexHigh;public uint IndexLow;
  }
  [StructLayout(LayoutKind.Sequential)] struct RENAME {
    public byte ReplaceIfExists;public IntPtr RootDirectory;
    public uint FileNameLength;public ushort FileName;
  }
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
  static extern SafeFileHandle CreateFileW(string name,uint access,uint share,
    IntPtr security,uint disposition,uint flags,IntPtr template);
  [DllImport("kernel32.dll",SetLastError=true)]
  static extern bool GetFileInformationByHandle(SafeFileHandle handle,out INFO info);
  [DllImport("kernel32.dll",SetLastError=true)]
  static extern bool SetFileInformationByHandle(SafeFileHandle handle,int cls,
    IntPtr buffer,uint length);
  static JavaScriptSerializer serializer=new JavaScriptSerializer();
  class Stop:Exception {public string Code;public int Native;public Stop(string c,int n=0){Code=c;Native=n;}}
  static void Need(bool ok,string code){if(!ok)throw new Stop(code);}
  static INFO Info(SafeFileHandle h){INFO i;if(!GetFileInformationByHandle(h,out i))throw new Stop("C996_NATIVE_IDENTITY_FAILED",Marshal.GetLastWin32Error());return i;}
  static string Identity(INFO i){return i.Volume.ToString("x8")+":"+(((ulong)i.IndexHigh<<32)|i.IndexLow).ToString("x16");}
  static string Sha(Stream s){using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(s)).Replace("-","").ToLowerInvariant();}
  static SafeFileHandle OpenDir(string p,bool moving,bool readMoved=false){
    var h=CreateFileW(p,READ_ATTRIBUTES|(moving?DELETE:0),SHARE_READ|SHARE_WRITE|(readMoved?4u:0u),
      IntPtr.Zero,OPEN_EXISTING,BACKUP_SEMANTICS|OPEN_REPARSE_POINT,IntPtr.Zero);
    if(h.IsInvalid)throw new Stop("C996_NATIVE_DIRECTORY_OPEN_FAILED",Marshal.GetLastWin32Error());
    var i=Info(h);if((i.Attr&ATTR_REPARSE)!=0||(i.Attr&ATTR_DIRECTORY)==0){h.Dispose();throw new Stop("C996_NATIVE_REPARSE_OR_NOT_DIRECTORY");}return h;
  }
  static void HoldParents(string root,string p,List<SafeFileHandle> held){
    string at=Path.GetPathRoot(p);Need(!String.IsNullOrEmpty(at),"C996_NATIVE_PATH_INVALID");
    held.Add(OpenDir(at,false));
    string relative=p.Substring(at.Length);foreach(string part in relative.Split(Path.DirectorySeparatorChar)){
      if(part.Length==0)continue;at=Path.Combine(at,part);held.Add(OpenDir(at,false));
    }
  }
  static string PathChecked(string root,string p){
    Need(p!=null&&p.Length<512&&!p.StartsWith(@"\\")&&!p.Contains("/../"),"C996_NATIVE_PATH_INVALID");
    string f=Path.GetFullPath(p),r=Path.GetFullPath(root).TrimEnd('\\')+"\\";
    Need(f.StartsWith(r,StringComparison.OrdinalIgnoreCase)&&
      Path.GetPathRoot(f).Equals(Path.GetPathRoot(r),StringComparison.OrdinalIgnoreCase),"C996_NATIVE_ROOT_ESCAPE");return f;
  }
  static Dictionary<string,object> Capture(string p,SafeFileHandle dir,List<FileStream> streams){
    var initial=Info(dir);var names=Directory.GetFileSystemEntries(p);Array.Sort(names,StringComparer.OrdinalIgnoreCase);
    Need(names.Length>0&&names.Length<=32,"C996_NATIVE_FILE_SET_INVALID");
    var files=new SortedDictionary<string,object>(StringComparer.Ordinal);
    foreach(string file in names){
      string name=Path.GetFileName(file);Need(name.EndsWith(".json",StringComparison.Ordinal)&&!files.ContainsKey(name),"C996_NATIVE_FILE_NAME_INVALID");
      var h=CreateFileW(file,GENERIC_READ,SHARE_READ,IntPtr.Zero,OPEN_EXISTING,OPEN_REPARSE_POINT,IntPtr.Zero);
      if(h.IsInvalid)throw new Stop("C996_NATIVE_FILE_OPEN_FAILED",Marshal.GetLastWin32Error());
      var info=Info(h);if((info.Attr&(ATTR_REPARSE|ATTR_DIRECTORY))!=0||info.Links!=1){h.Dispose();throw new Stop("C996_NATIVE_FILE_REDIRECT_OR_LINK");}
      ulong size=((ulong)info.SizeHigh<<32)|info.SizeLow;Need(size>0&&size<=262144,"C996_NATIVE_FILE_SIZE_INVALID");
      var stream=new FileStream(h,FileAccess.Read);streams.Add(stream);string sha=Sha(stream);
      Need(Identity(Info(h))==Identity(info),"C996_NATIVE_FILE_IDENTITY_DRIFT");
      files.Add(name,new Dictionary<string,object>{{"identity",Identity(info)},{"sha256",sha},{"size",size}});
    }
    var again=Directory.GetFileSystemEntries(p);Array.Sort(again,StringComparer.OrdinalIgnoreCase);
    Need(String.Join("\n",names)==String.Join("\n",again)&&Identity(Info(dir))==Identity(initial),"C996_NATIVE_SNAPSHOT_RACE");
    return new Dictionary<string,object>{{"identity",Identity(initial)},{"files",files}};
  }
  static void SameSnapshot(Dictionary<string,object> current,Dictionary<string,object> expected){
    Need((string)current["identity"]==(string)expected["identity"],"C996_NATIVE_SOURCE_IDENTITY_DRIFT");
    var a=(SortedDictionary<string,object>)current["files"];var b=(IDictionary<string,object>)expected["files"];
    Need(a.Count==b.Count,"C996_NATIVE_SOURCE_FILE_SET_DRIFT");
    foreach(var entry in a){
      Need(b.ContainsKey(entry.Key),"C996_NATIVE_SOURCE_FILE_SET_DRIFT");
      var x=(Dictionary<string,object>)entry.Value;var y=(Dictionary<string,object>)b[entry.Key];
      Need((string)x["identity"]==(string)y["identity"]&&(string)x["sha256"]==(string)y["sha256"]&&
        Convert.ToUInt64(x["size"])==Convert.ToUInt64(y["size"]),"C996_NATIVE_SOURCE_CONTENT_DRIFT");
    }
  }
  public static string Execute(string raw){
    var held=new List<SafeFileHandle>();var streams=new List<FileStream>();SafeFileHandle sourceHandle=null;IntPtr buffer=IntPtr.Zero;
    bool moveOccurred=false;
    try{
      Need(raw!=null&&raw.Length<65536,"C996_NATIVE_INPUT_INVALID");
      var args=serializer.Deserialize<Dictionary<string,object>>(raw);
      string op=(string)args["operation"],root=(string)args["root"];
      Need(op=="move","C996_NATIVE_OPERATION_INVALID");
      string temp=Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar);
      root=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar);
      if (Fixture) {
      Need(String.Equals(Path.GetDirectoryName(root),temp,StringComparison.OrdinalIgnoreCase)&&
        System.Text.RegularExpressions.Regex.IsMatch(Path.GetFileName(root),@"\Azgmini-996-handle-fixture-[A-Za-z0-9]+\z")&&
        !root.StartsWith(@"E:\ZGmini\",StringComparison.OrdinalIgnoreCase),"C996_NATIVE_TEMP_FIXTURE_REQUIRED");
      } else {
        Need(String.Equals(root,@"E:\ZGmini\automation\pc-maintenance\leases",StringComparison.OrdinalIgnoreCase),
          "C996_NATIVE_ORIGINAL_ROOT_REQUIRED");
      }
      string source=PathChecked(root,(string)args["source"]);
      Need(String.Equals(Path.GetDirectoryName(source),root,StringComparison.OrdinalIgnoreCase),"C996_NATIVE_FIXED_SOURCE_REQUIRED");
      HoldParents(root,root,held);
      sourceHandle=OpenDir(source,op=="move");
      var snap=Capture(source,sourceHandle,streams);
      string destination=PathChecked(root,(string)args["destination"]);
      Need(Path.GetDirectoryName(source).Equals(Path.GetDirectoryName(destination),StringComparison.OrdinalIgnoreCase),"C996_NATIVE_PARENT_MISMATCH");
      Need(!String.Equals(source,destination,StringComparison.OrdinalIgnoreCase),"C996_NATIVE_FIXED_DESTINATION_REQUIRED");
      var pins=(Dictionary<string,object>)args["pins"];
      var seen=(SortedDictionary<string,object>)snap["files"];
      Need(pins.Count==seen.Count&&pins.ContainsKey("owner.json"),"C996_NATIVE_SOURCE_FILE_SET_DRIFT");
      foreach(var file in seen) {
        Need(pins.ContainsKey(file.Key)&&
          (string)((Dictionary<string,object>)file.Value)["sha256"]==(string)pins[file.Key],"C996_NATIVE_SOURCE_CONTENT_DRIFT");
      }
      var owner=serializer.Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(source,"owner.json")));
      int pid=Convert.ToInt32(owner["pid"]);
      Need(pid>0,"C996_NATIVE_OWNER_PID_INVALID");
      var mode=(string)args["ownerMode"];
      bool alive;
      try { using(var process=System.Diagnostics.Process.GetProcessById(pid)) { alive=!process.HasExited; } }
      catch(ArgumentException) { alive=false; }
      if(mode=="LIVE_NEW") {
        Need(alive&&pid==Convert.ToInt32(args["actorPid"])&&
          (string)owner["nonce"]==(string)args["nonce"],"C996_NATIVE_NEW_OWNER_DRIFT");
      } else {
        Need((mode=="DEAD_OLD"||mode=="DEAD_INSTALL")&&!alive,"C996_NATIVE_OLD_OWNER_LIVE_OR_UNKNOWN");
        if(mode=="DEAD_OLD") {
          string nonce=(string)owner["nonce"];
          Need(!String.IsNullOrEmpty(nonce),"C996_NATIVE_OLD_NONCE_DRIFT");
          foreach(string marker in new[]{"PREPARED","WORKFLOW_ENABLE_ATTEMPTED","BACKLOG_CLOSE_ATTEMPTED"}) {
            var value=serializer.Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(source,marker+".json")));
            Need((string)value["ownerNonce"]==nonce,"C996_NATIVE_OLD_NONCE_DRIFT");
          }
        }
      }
      string leaf=Path.GetFileName(destination);Need(leaf.Length>0&&!leaf.Contains(":"),"C996_NATIVE_DESTINATION_INVALID");
      // All ancestors and the common parent stay open without SHARE_DELETE.
      // Windows rejected RootDirectory+leaf; use an absolute NT name instead.
      var parent=held[held.Count-1];var parentBefore=Identity(Info(parent));
      byte[] bytes=System.Text.Encoding.Unicode.GetBytes(@"\??\"+destination);
      int nameOffset=Marshal.OffsetOf(typeof(RENAME),"FileName").ToInt32();
      int rootOffset=Marshal.OffsetOf(typeof(RENAME),"RootDirectory").ToInt32();
      int lenOffset=Marshal.OffsetOf(typeof(RENAME),"FileNameLength").ToInt32();
      int length=nameOffset+bytes.Length+2;buffer=Marshal.AllocHGlobal(length);
      for(int i=0;i<length;i++)Marshal.WriteByte(buffer,i,0);
      Marshal.WriteIntPtr(buffer,rootOffset,IntPtr.Zero);
      Marshal.WriteInt32(buffer,lenOffset,bytes.Length);Marshal.Copy(bytes,0,IntPtr.Add(buffer,nameOffset),bytes.Length);
      // Keep every verified child open without write or delete sharing.
      // A volume that refuses the directory move in this state is unsupported.
      if(Fixture&&args.ContainsKey("simulateContentDrift")&&
        (bool)args["simulateContentDrift"]) {
        try { File.AppendAllText(Path.Combine(source,"owner.json")," "); }
        catch(IOException) { throw new Stop("C996_NATIVE_COMPETING_WRITE_BLOCKED"); }
        throw new Stop("C996_NATIVE_COMPETING_WRITE_NOT_BLOCKED");
      }
      // TEMP-only negative proof: an unpinned child can be created while
      // parent and each originally pinned child handle are still held. The
      // fixture refuses to archive; never remove this guard for production.
      if(Fixture&&args.ContainsKey("simulateNamespaceInsert")&&
        (bool)args["simulateNamespaceInsert"]) {
        string extra=Path.Combine(source,"competing.json");
        try {
          using(var stream=new FileStream(extra,FileMode.CreateNew,FileAccess.Write,FileShare.None)){
            stream.WriteByte(123);stream.WriteByte(125);stream.Flush(true);
          }
        } catch(IOException) { throw new Stop("C996_NATIVE_COMPETING_INSERT_BLOCKED"); }
        throw new Stop("C996_NATIVE_COMPETING_INSERT_NOT_BLOCKED");
      }
      // Child share locks protect the verified files, not insertion of a new
      // directory entry. No production move until the whole inventory can be
      // held stable through the namespace operation.
      Need(Fixture,"C996_NATIVE_NAMESPACE_ATOMICITY_UNPROVEN");
      if(!SetFileInformationByHandle(sourceHandle,3,buffer,(uint)length)){
        int error=Marshal.GetLastWin32Error();throw new Stop(error==183||error==80?"C996_NATIVE_DESTINATION_EXISTS":
          error==5||error==32?"C996_NATIVE_LOCKED_MOVE_UNSUPPORTED":"C996_NATIVE_RENAME_UNCERTAIN",error);
      }
      moveOccurred=true;
      Need(Identity(Info(sourceHandle))==(string)snap["identity"]&&Identity(Info(parent))==parentBefore,"C996_NATIVE_RENAME_IDENTITY_DRIFT");
      // Verify every original file identity and hash after the namespace move.
      using(var after=OpenDir(destination,false,true)){
        var post=Capture(destination,after,streams);SameSnapshot(post,snap);
        return serializer.Serialize(new Dictionary<string,object>{{"ok",true},{"snapshot",post},{"noReplace",true},{"sourceHandleBound",true},{"parentIdentity",parentBefore},{"namespacePowerLossDurabilityProven",false}});
      }
    }catch(Stop e){return serializer.Serialize(new Dictionary<string,object>{{"ok",false},{"code",e.Code},{"nativeError",e.Native},{"moveOccurred",moveOccurred}});}
    catch{return serializer.Serialize(new Dictionary<string,object>{{"ok",false},{"code","C996_NATIVE_STORAGE_UNCERTAIN"},{"moveOccurred",moveOccurred}});}
    finally{if(buffer!=IntPtr.Zero)Marshal.FreeHGlobal(buffer);foreach(var s in streams)s.Dispose();if(sourceHandle!=null)sourceHandle.Dispose();foreach(var h in held)h.Dispose();}
  }
}
'@ -ReferencedAssemblies 'System.Web.Extensions'
  $raw = [Console]::In.ReadToEnd()
  $result = [C996NativeDirectory]::Execute($raw)
  [Console]::Out.WriteLine($result)
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
  [Console]::Out.WriteLine('{"ok":false,"code":"C996_NATIVE_BRIDGE_UNAVAILABLE"}')
  exit 2
}
`.replace('__FIXTURE__',fixture?'true':'false');
}

export function build996OwnerTransactionalArchiveFixtureScript(){
  return transactionalArchiveScript(true);
}

// The real and TEMP variants share this exact native CAS implementation.
// Only the compiled root boundary differs. The operational entry remains
// independently blocked above the first import/write pending final approval.
function transactionalArchiveScript(fixture=false){
  return String.raw`
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
Add-Type -AssemblyName System.Web.Extensions
Add-Type -TypeDefinition @'
using System;using System.IO;using System.Collections.Generic;
using System.Runtime.InteropServices;using System.Security.Cryptography;
using System.Web.Script.Serialization;using Microsoft.Win32.SafeHandles;
public static class C996TransactionalArchive {
 static readonly bool Fixture=__FIXTURE__;
 const uint Reparse=0x400,DirectoryAttribute=0x10,ReadAttributes=0x80,ReadControl=0x20000;
 const uint GenericRead=0x80000000,GenericWrite=0x40000000;
 [StructLayout(LayoutKind.Sequential)]struct FT {public uint Low,High;}
 [StructLayout(LayoutKind.Sequential)]struct InfoData {public uint Attr;public FT Created,Accessed,Written;public uint Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;}
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]struct FindData {public uint Attr;public FT Created,Accessed,Written;public uint SizeHigh,SizeLow,Reserved0,Reserved1;[MarshalAs(UnmanagedType.ByValTStr,SizeConst=260)]public string Name;[MarshalAs(UnmanagedType.ByValTStr,SizeConst=14)]public string Alternate;}
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern SafeFileHandle CreateFileW(string p,uint a,uint s,IntPtr security,uint d,uint flags,IntPtr template);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern SafeFileHandle CreateFileTransactedW(string p,uint a,uint s,IntPtr security,uint d,uint flags,IntPtr template,IntPtr tx,IntPtr version,IntPtr extended);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetFileInformationByHandle(SafeFileHandle h,out InfoData i);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool MoveFileTransactedW(string a,string b,IntPtr progress,IntPtr data,uint flags,IntPtr tx);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr FindFirstFileTransactedW(string p,int level,out FindData data,int search,IntPtr filter,uint flags,IntPtr tx);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool FindNextFileW(IntPtr h,out FindData data);
 [DllImport("kernel32.dll")]static extern bool FindClose(IntPtr h);
 [DllImport("kernel32.dll")]static extern bool CloseHandle(IntPtr h);
 [DllImport("KtmW32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr CreateTransaction(IntPtr a,IntPtr b,uint c,uint d,uint e,uint timeout,string description);
 [DllImport("KtmW32.dll",SetLastError=true)]static extern bool CommitTransaction(IntPtr h);
 [DllImport("KtmW32.dll",SetLastError=true)]static extern bool RollbackTransaction(IntPtr h);
 [DllImport("advapi32.dll",SetLastError=true)]static extern uint GetSecurityInfo(IntPtr h,int type,uint flags,out IntPtr owner,out IntPtr group,out IntPtr dacl,out IntPtr sacl,out IntPtr descriptor);
 [DllImport("advapi32.dll")]static extern uint GetSecurityDescriptorLength(IntPtr p);
 [DllImport("kernel32.dll")]static extern IntPtr LocalFree(IntPtr p);
 static readonly JavaScriptSerializer Json=new JavaScriptSerializer();
 class Stop:Exception {public string Code;public int Native;public Stop(string c,int n=0){Code=c;Native=n;}}
 static void Need(bool ok,string code){if(!ok)throw new Stop(code);}
 static string Hash(byte[] bytes){using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(bytes)).Replace("-","").ToLowerInvariant();}
 static InfoData Info(SafeFileHandle h){InfoData i;if(!GetFileInformationByHandle(h,out i))throw new Stop("C996_NATIVE_TX_IDENTITY_FAILED",Marshal.GetLastWin32Error());return i;}
 static string Id(InfoData i){return i.Volume.ToString("x8")+":"+(((ulong)i.IndexHigh<<32)|i.IndexLow).ToString("x16");}
 static string Acl(SafeFileHandle h){IntPtr a,b,c,d,sd;uint e=GetSecurityInfo(h.DangerousGetHandle(),1,7,out a,out b,out c,out d,out sd);Need(e==0,"C996_NATIVE_TX_ACL_UNAVAILABLE");try{uint size=GetSecurityDescriptorLength(sd);Need(size>0&&size<=65536,"C996_NATIVE_TX_ACL_INVALID");var bytes=new byte[size];Marshal.Copy(sd,bytes,0,(int)size);return Hash(bytes);}finally{LocalFree(sd);}}
 static SafeFileHandle Open(string p,bool directory,IntPtr tx){
  uint access=directory?ReadAttributes|ReadControl:GenericRead|(tx!=IntPtr.Zero?GenericWrite:0);
  uint flags=0x00200000u|(directory?0x02000000u:0);
  var h=tx==IntPtr.Zero?CreateFileW(p,access,7,IntPtr.Zero,3,flags,IntPtr.Zero):CreateFileTransactedW(p,access,1,IntPtr.Zero,3,flags,IntPtr.Zero,tx,IntPtr.Zero,IntPtr.Zero);
  if(h.IsInvalid){int error=Marshal.GetLastWin32Error();h.Dispose();throw new Stop("C996_NATIVE_TX_OPEN_FAILED",error);}
  var i=Info(h);if((i.Attr&Reparse)!=0||((i.Attr&DirectoryAttribute)!=0)!=directory||(!directory&&(i.Links!=1||i.SizeHigh!=0||i.SizeLow==0||i.SizeLow>262144))){h.Dispose();throw new Stop("C996_NATIVE_TX_UNSAFE_ENTRY");}return h;
 }
 static void HoldParents(string parent,List<SafeFileHandle> held){
  string at=Path.GetPathRoot(parent);foreach(string part in new string[]{""}.ConcatParts(parent.Substring(at.Length))){
   if(part.Length>0)at=Path.Combine(at,part);
   var h=CreateFileW(at,ReadAttributes,3,IntPtr.Zero,3,0x02200000,IntPtr.Zero);
   if(h.IsInvalid){int e=Marshal.GetLastWin32Error();h.Dispose();throw new Stop("C996_NATIVE_TX_PARENT_OPEN_FAILED",e);}
   var i=Info(h);if((i.Attr&Reparse)!=0||(i.Attr&DirectoryAttribute)==0){h.Dispose();throw new Stop("C996_NATIVE_TX_PARENT_REDIRECT");}held.Add(h);
  }
 }
 static string[] Names(string dir,IntPtr tx){
  var names=new List<string>();
  if(tx==IntPtr.Zero){foreach(string p in System.IO.Directory.GetFileSystemEntries(dir))names.Add(Path.GetFileName(p));}
  else{FindData data;IntPtr f=FindFirstFileTransactedW(Path.Combine(dir,"*"),0,out data,0,IntPtr.Zero,0,tx);if(f==new IntPtr(-1))throw new Stop("C996_NATIVE_TX_ENUMERATION_FAILED",Marshal.GetLastWin32Error());try{do{if(data.Name!="."&&data.Name!="..")names.Add(data.Name);}while(FindNextFileW(f,out data));Need(Marshal.GetLastWin32Error()==18,"C996_NATIVE_TX_ENUMERATION_INCOMPLETE");}finally{FindClose(f);}}
  Need(names.Count>0&&names.Count<=7,"C996_NATIVE_TX_FILE_SET_INVALID");names.Sort(StringComparer.Ordinal);return names.ToArray();
 }
 static Dictionary<string,object> Capture(string dir,IntPtr tx,List<FileStream> held,out byte[] owner){
  owner=null;using(var d=Open(dir,true,tx)){
   var result=new Dictionary<string,object>();result["identity"]=Id(Info(d));result["aclSha256"]=Acl(d);
   var files=new SortedDictionary<string,object>(StringComparer.Ordinal);string[] before=Names(dir,tx);
   foreach(string name in before){Need(System.Text.RegularExpressions.Regex.IsMatch(name,@"\A(?:owner|[A-Z0-9_]{3,64})\.json\z"),"C996_NATIVE_TX_FILE_NAME_INVALID");
    var h=Open(Path.Combine(dir,name),false,tx);FileStream stream;try{stream=new FileStream(h,tx==IntPtr.Zero?FileAccess.Read:FileAccess.ReadWrite);}catch{h.Dispose();throw;}
    bool retain=false;try{var i=Info(h);byte[] bytes=new byte[i.SizeLow];int at=0,n;while(at<bytes.Length&&(n=stream.Read(bytes,at,bytes.Length-at))>0)at+=n;Need(at==bytes.Length&&stream.ReadByte()==-1,"C996_NATIVE_TX_SHORT_READ");
     files.Add(name,new Dictionary<string,object>{{"identity",Id(i)},{"sha256",Hash(bytes)},{"size",i.SizeLow},{"aclSha256",Acl(h)}});Need(Id(Info(h))==Id(i),"C996_NATIVE_TX_FILE_IDENTITY_DRIFT");if(name=="owner.json")owner=bytes;
     if(tx!=IntPtr.Zero){held.Add(stream);retain=true;}
    }finally{if(!retain)stream.Dispose();}
   }
   Need(String.Join("\n",before)==String.Join("\n",Names(dir,tx)),"C996_NATIVE_TX_NAMESPACE_DRIFT");result["files"]=files;return result;
  }
 }
 static void VerifyPins(Dictionary<string,object> snapshot,Dictionary<string,object> pins){
  var files=(SortedDictionary<string,object>)snapshot["files"];Need(files.Count==pins.Count&&pins.ContainsKey("owner.json"),"C996_NATIVE_TX_PIN_SET_DRIFT");foreach(var e in files)Need(pins.ContainsKey(e.Key)&&(string)((Dictionary<string,object>)e.Value)["sha256"]==(string)pins[e.Key],"C996_NATIVE_TX_PIN_BYTES_DRIFT");
 }
 static void Owner(byte[] bytes,Dictionary<string,object> args){
  var owner=Json.Deserialize<Dictionary<string,object>>(System.Text.Encoding.UTF8.GetString(bytes));int pid=Convert.ToInt32(owner["pid"]);Need(pid>0,"C996_NATIVE_TX_OWNER_INVALID");
  string mode=(string)args["ownerMode"];
  if(mode=="LIVE_NEW"){Need(pid==Convert.ToInt32(args["actorPid"])&&owner.ContainsKey("nonce")&&(string)owner["nonce"]==(string)args["nonce"],"C996_NATIVE_TX_OWNER_CHANGED");try{Need(!System.Diagnostics.Process.GetProcessById(pid).HasExited,"C996_NATIVE_TX_OWNER_NOT_LIVE");}catch(ArgumentException){throw new Stop("C996_NATIVE_TX_OWNER_NOT_LIVE");}}
  else{Need(mode=="DEAD_OLD"||mode=="DEAD_INSTALL","C996_NATIVE_TX_OWNER_MODE_INVALID");try{var p=System.Diagnostics.Process.GetProcessById(pid);Need(p.HasExited,"C996_NATIVE_TX_OLD_OWNER_ALIVE");}catch(ArgumentException){}}
 }
 public static string Run(string raw){
  IntPtr tx=IntPtr.Zero;bool committed=false,attempted=false;var parents=new List<SafeFileHandle>();var streams=new List<FileStream>();
  try{
   Need(raw!=null&&raw.Length<=65536,"C996_NATIVE_TX_INPUT_INVALID");var a=Json.Deserialize<Dictionary<string,object>>(raw);Need((string)a["operation"]=="move","C996_NATIVE_TX_OPERATION_INVALID");
   string root=Path.GetFullPath((string)a["root"]).TrimEnd('\\');string temp=Path.GetFullPath(Path.GetTempPath()).TrimEnd('\\');
   if(Fixture)Need(String.Equals(Path.GetDirectoryName(root),temp,StringComparison.OrdinalIgnoreCase)&&System.Text.RegularExpressions.Regex.IsMatch(Path.GetFileName(root),@"\Azgmini-996-txf-cas-[A-Za-z0-9]+\z"),"C996_NATIVE_TX_TEMP_ONLY");
   else Need(String.Equals(root,@"E:\ZGmini\automation\pc-maintenance\leases",StringComparison.OrdinalIgnoreCase),"C996_NATIVE_TX_ORIGINAL_ROOT_REQUIRED");
   string source=Path.GetFullPath((string)a["source"]),destination=Path.GetFullPath((string)a["destination"]);
   Need(String.Equals(Path.GetDirectoryName(source),root,StringComparison.OrdinalIgnoreCase)&&String.Equals(Path.GetDirectoryName(destination),root,StringComparison.OrdinalIgnoreCase)&&!String.Equals(source,destination,StringComparison.OrdinalIgnoreCase),"C996_NATIVE_TX_PATH_INVALID");
   HoldParents(root,parents);byte[] owner;var before=Capture(source,IntPtr.Zero,streams,out owner);var pins=(Dictionary<string,object>)a["pins"];VerifyPins(before,pins);Owner(owner,a);
   tx=CreateTransaction(IntPtr.Zero,IntPtr.Zero,0,0,0,15000,"ZGMINI #996 single archive CAS");Need(tx!=IntPtr.Zero&&tx!=new IntPtr(-1),"C996_NATIVE_TX_UNAVAILABLE");
   if(!MoveFileTransactedW(source,destination,IntPtr.Zero,IntPtr.Zero,0,tx))throw new Stop("C996_NATIVE_TX_STAGE_FAILED",Marshal.GetLastWin32Error());
   if(a.ContainsKey("fixtureInsert")){Need(Fixture,"C996_NATIVE_TX_FIXTURE_ONLY");using(var h=CreateFileTransactedW(Path.Combine(destination,"INJECTED.json"),GenericWrite,7,IntPtr.Zero,1,0,IntPtr.Zero,tx,IntPtr.Zero,IntPtr.Zero)){Need(!h.IsInvalid,"C996_NATIVE_TX_FIXTURE_INSERT_FAILED");using(var s=new FileStream(h,FileAccess.Write)){s.WriteByte(1);}}}
   byte[] stagedOwner;var staged=Capture(destination,tx,streams,out stagedOwner);VerifyPins(staged,pins);Owner(stagedOwner,a);Need(Json.Serialize(before)==Json.Serialize(staged),"C996_NATIVE_TX_ID_OR_ACL_DRIFT");
   if(a.ContainsKey("fixtureExternalRace")){Need(Fixture,"C996_NATIVE_TX_FIXTURE_ONLY");File.WriteAllText(Path.Combine(root,"race-ready.json"),"ready");var until=DateTime.UtcNow.AddSeconds(10);while(!File.Exists(Path.Combine(root,"race-done.json"))){Need(DateTime.UtcNow<until,"C996_NATIVE_TX_FIXTURE_RACE_TIMEOUT");System.Threading.Thread.Sleep(10);}}
   if(a.ContainsKey("fixtureTerminateAfterCas")){Need(Fixture,"C996_NATIVE_TX_FIXTURE_ONLY");Environment.Exit(17);}
   // Transacted writer handles pin content until commit, after the full
   // namespace, expected bytes, identities, ACL and owner checks succeed.
   attempted=true;if(!CommitTransaction(tx))throw new Stop("C996_NATIVE_TX_COMMIT_UNKNOWN",Marshal.GetLastWin32Error());committed=true;
   foreach(var s in streams)s.Dispose();streams.Clear();
   byte[] afterOwner;var after=Capture(destination,IntPtr.Zero,streams,out afterOwner);Need(Json.Serialize(before)==Json.Serialize(after),"C996_NATIVE_TX_POSTCHECK_UNKNOWN");
   return Json.Serialize(new Dictionary<string,object>{{"ok",true},{"strategy","WINDOWS_TXF_CAS_V1"},{"transactionCommitted",true},{"transactionIdentityVerified",true},{"pinsVerifiedBeforeCommit",true},{"aclPreserved",true},{"noReplace",true},{"sourceHandleBound",false},{"snapshot",after},{"sourceIdentity",before["identity"]},{"parentIdentity",Id(Info(parents[parents.Count-1]))},{"namespacePowerLossDurabilityProven",false}});
  }catch(Stop e){bool rolled=false;if(tx!=IntPtr.Zero&&tx!=new IntPtr(-1)&&!committed)rolled=RollbackTransaction(tx);return Json.Serialize(new Dictionary<string,object>{{"ok",false},{"code",e.Code},{"nativeError",e.Native},{"transactionCommitted",committed},{"commitAttempted",attempted},{"rollbackConfirmed",rolled}});}
  catch{bool rolled=false;if(tx!=IntPtr.Zero&&tx!=new IntPtr(-1)&&!committed)rolled=RollbackTransaction(tx);return Json.Serialize(new Dictionary<string,object>{{"ok",false},{"code","C996_NATIVE_TX_OUTCOME_UNKNOWN"},{"transactionCommitted",committed},{"commitAttempted",attempted},{"rollbackConfirmed",rolled}});}
  finally{foreach(var s in streams)s.Dispose();if(tx!=IntPtr.Zero&&tx!=new IntPtr(-1))CloseHandle(tx);foreach(var h in parents)h.Dispose();}
 }
}
public static class C996PathParts {public static IEnumerable<string> ConcatParts(this string[] first,string rest){foreach(string s in first)yield return s;foreach(string s in rest.Split('\\'))if(s.Length>0)yield return s;}}
'@ -ReferencedAssemblies 'System.Web.Extensions'
[Console]::WriteLine([C996TransactionalArchive]::Run([Console]::In.ReadToEnd()))
`.replace('__FIXTURE__',fixture?'true':'false');
}

function moveNoReplace(from,to,{files,ownerMode,actorPid=null,nonce=null}){
  const source=path.win32.normalize(from).toLowerCase();
  const target=path.win32.normalize(to).toLowerCase();
  const parent=path.win32.normalize(LEASES).toLowerCase();
  need(path.win32.dirname(source)===parent&&
    path.win32.dirname(target)===parent&&
    source!==target&&source.startsWith(parent+'\\')&&
    target.startsWith(parent+'\\'),
    'C_996_OWNER_MOVE_NOT_SAME_PARENT');
  safeLeaseDirectory(path.basename(from));
  safeLeaseDirectory('');
  need(absent(to),'C_996_OWNER_ARCHIVE_DESTINATION_PRESENT');
  // The source inventory is built only from physically rechecked manifest
  // pins or the new fsynced owner/marker hashes in this module, never a
  // caller-provided permission port. The native child repeats this CAS.
  need(files&&typeof files==='object'&&!Array.isArray(files)&&
    Object.keys(files).length>=1&&Object.keys(files).length<=7&&
    H64(files['owner.json'])&&Object.entries(files).every(([k,v])=>
      /^(?:owner|PREPARED|WORKFLOW_ENABLE_ATTEMPTED|BACKLOG_CLOSE_ATTEMPTED|RECOVERY_REQUIRED|OLD_C_CLAIM_ARCHIVE_ATTEMPTED|READY_TO_RELEASE_INSTALL)\.json$/.test(k)&&
      H64(v))&&
    ['LIVE_NEW','DEAD_OLD','DEAD_INSTALL'].includes(ownerMode)&&
    (ownerMode!=='LIVE_NEW'||
      Number.isSafeInteger(actorPid)&&actorPid>0&&UUID(nonce)),
  'C_996_OWNER_NATIVE_INVENTORY_INVALID');
  let receipt;
  try {
    receipt=JSON.parse(execFileSync(PS,['-NoProfile','-NonInteractive','-Command',transactionalArchiveScript()],{
      input:JSON.stringify({operation:'move',root:LEASES,source:from,destination:to,pins:files,ownerMode,actorPid,nonce}),
      encoding:'utf8',windowsHide:true,timeout:30_000,maxBuffer:100_000,stdio:['pipe','pipe','pipe'],
    }));
  } catch {need(false,'C_996_OWNER_NATIVE_MOVE_UNKNOWN');}
  require996OwnerArchiveReceipt(receipt,files);
  need(receipt.strategy==='WINDOWS_TXF_CAS_V1','C_996_OWNER_TRANSACTIONAL_RECEIPT_REQUIRED');
  need(absent(from)&&fs.lstatSync(to).isDirectory(),
    'C_996_OWNER_NATIVE_MOVE_POSTCHECK_UNKNOWN');
}

// A native success flag is not enough: the move receipt must carry an
// independently parseable, exact post-move child inventory matching the
// pre-move approved SHA-256 pins. TxF also requires the commit, identity and
// ACL attestations from the pinned native child. Neither receipt authorizes
// production execution; the upstream C hard STOP remains.
export function require996OwnerArchiveReceipt(receipt,pins){
  const transactional=receipt?.strategy==='WINDOWS_TXF_CAS_V1';
  need(receipt?.ok===true&&receipt.noReplace===true&&
    (transactional?receipt.transactionCommitted===true&&receipt.transactionIdentityVerified===true&&
      receipt.pinsVerifiedBeforeCommit===true&&receipt.aclPreserved===true:
      receipt.sourceHandleBound===true),
    /^C996_NATIVE_[A-Z0-9_]+$/.test(receipt?.code??'')?receipt.code:'C_996_OWNER_NATIVE_MOVE_UNKNOWN');
  const id=x=>typeof x==='string'&&/^[a-f0-9]{8}:[a-f0-9]{16}$/.test(x);
  const snapshot=receipt.snapshot,observed=snapshot?.files;
  const entries=observed&&typeof observed==='object'&&!Array.isArray(observed)?
    Object.entries(observed):[];
  need(id(snapshot?.identity)&&id(receipt.parentIdentity)&&
    (!transactional||receipt.sourceIdentity===snapshot.identity&&H64(snapshot.aclSha256))&&
    pins&&typeof pins==='object'&&!Array.isArray(pins)&&
    Object.keys(pins).length>=1&&Object.keys(pins).length<=7&&
    entries.length===Object.keys(pins).length&&
    entries.every(([name,file])=>Object.hasOwn(pins,name)&&
      H64(pins[name])&&file&&typeof file==='object'&&!Array.isArray(file)&&
      id(file.identity)&&file.identity!==snapshot.identity&&
      file.sha256===pins[name]&&
      (!transactional||H64(file.aclSha256))&&
      Number.isSafeInteger(file.size)&&file.size>0&&file.size<=262144)&&
    new Set(entries.map(([,file])=>file.identity)).size===entries.length,
    'C_996_OWNER_NATIVE_POSTMOVE_RECEIPT_DRIFT');
}

function gitContentAtCommit(relFile,commit){
  need([...FILES,LOCK_REPO,PACKAGE_REPO].includes(relFile)&&H40(commit),
    'C_996_OWNER_GIT_SOURCE_PATH_INVALID');
  const route=`repos/${REPO}/contents/${relFile}?ref=${commit}`;
  let data;
  try{data=JSON.parse(execFileSync(GH,['api','--method','GET',route],{
    encoding:'utf8',windowsHide:true,timeout:30_000,
    maxBuffer:24_000_000,stdio:['ignore','pipe','pipe'],
  }));}catch{need(false,'C_996_OWNER_GIT_CONTENT_UNAVAILABLE');}
  need(data?.type==='file'&&data.path===relFile&&
    data.encoding==='base64'&&H40(data.sha)&&
    Number.isSafeInteger(data.size)&&data.size>0&&data.size<=16_000_000&&
    typeof data.content==='string',
    'C_996_OWNER_GIT_CONTENT_INVALID');
  const normalized=data.content.replace(/\s/g,'');
  need(/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(normalized),
    'C_996_OWNER_GIT_BASE64_INVALID');
  const bytes=Buffer.from(normalized,'base64');
  need(bytes.length===data.size&&bytes.toString('base64')===normalized&&
    blobSHA(bytes)===data.sha,'C_996_OWNER_GIT_BYTES_UNVERIFIED');
  return bytes;
}
function checkSourceBundle(manifest,manifestCommitSha){
  const operator=safeFile(fileURLToPath(import.meta.url),2_000_000);
  const packageBytes=safeFile(LOCAL_PACKAGE,16_000_000);
  const lockBytes=safeFile(LOCAL_LOCK,100_000);
  need(sha(operator)===manifest.operatorSha256&&
    sha(packageBytes)===manifest.packageSha256&&
    sha(lockBytes)===manifest.sourceLockSha256,
    'C_996_OWNER_SOURCE_BYTES_NOT_PINNED');
  for(const [relFile,local,commit] of [
    [SELF_REPO,operator,manifest.operatorCommit],
    [LOCK_REPO,lockBytes,manifestCommitSha],
    [PACKAGE_REPO,packageBytes,manifestCommitSha],
  ])need(gitContentAtCommit(relFile,commit).equals(local),
    'C_996_OWNER_GIT_COMMIT_SOURCE_DRIFT');
  let lock;try{lock=JSON.parse(lockBytes.toString('utf8'));}catch{}
  need(lock?.schema==='ZGMINI_CONTROLLER_996_NATIVE_OWNER_SOURCE_LOCK_V1'&&
    same(Object.keys(lock).sort(),['schema','files'].sort())&&lock.files&&
    same(Object.keys(lock.files).sort(),FILES.slice().sort()),
    'C_996_OWNER_SOURCE_LOCK_SCHEMA_INVALID');
  for(const repoFile of FILES){
    need(H64(lock.files[repoFile]),'C_996_OWNER_SOURCE_LOCK_DIGEST_INVALID');
    const full=path.join(DIR,path.basename(repoFile));
    const local=safeFile(full,2_000_000);
    need(sha(local)===lock.files[repoFile]&&
      gitContentAtCommit(repoFile,manifest.operatorCommit).equals(local),
      'C_996_OWNER_IMPORT_SOURCE_LOCK_DRIFT');
  }
  return {operator,packageBytes,lockBytes};
}

// Review-only import boundary. The independently pinned outer Windows
// launcher retains source handles. In addition, return the validated bytes
// directly to Node's synchronous loader instead of reading the paths again.
// This is NOT Owner consent and never enables the operational C function.
function pin996ReviewImports(claimed){
  need(typeof registerHooks==='function'&&H64(claimed?.sourceLockSha256),
    'C_996_OWNER_PINNED_LOADER_UNAVAILABLE');
  const lockBytes=safeFile(LOCAL_LOCK,100_000);
  need(sha(lockBytes)===claimed.sourceLockSha256,'C_996_OWNER_HANDOFF_LOCK_DRIFT');
  let lock;try{lock=JSON.parse(lockBytes.toString('utf8'));}catch{}
  need(lock?.schema==='ZGMINI_CONTROLLER_996_NATIVE_OWNER_SOURCE_LOCK_V1'&&
    lock.files&&Object.keys(lock.files).length===16,
    'C_996_OWNER_HANDOFF_LOCK_INVALID');
  const sources=new Map();
  for(const [relative,expected] of Object.entries(lock.files)){
    need(/^tools\/controller-996-[a-z0-9-]+\.(mjs|json)$/.test(relative)&&H64(expected),
      'C_996_OWNER_HANDOFF_IMPORT_PATH_INVALID');
    const full=path.join(DIR,path.basename(relative));
    const bytes=safeFile(full,2_000_000);
    need(sha(bytes)===expected,'C_996_OWNER_HANDOFF_IMPORT_BYTES_DRIFT');
    if(relative.endsWith('.mjs'))sources.set(pathToFileURL(full).href,bytes.toString('utf8'));
  }
  for(const [relative,pin] of [
    [SELF_REPO,claimed.operatorSha256],
    ['tools/controller-996-c-native-trusted-bootstrap.mjs',claimed.bootstrapSha256],
  ])need(H64(pin)&&lock.files[relative]===pin,'C_996_OWNER_HANDOFF_ENTRY_PIN_DRIFT');
  return registerHooks({
    resolve(specifier,context,nextResolve){
      if(specifier.startsWith('node:')&&isBuiltin(specifier))return nextResolve(specifier,context);
      let url;try{url=new URL(specifier,context.parentURL).href;}catch{}
      need(sources.has(url),'C_996_OWNER_UNSEALED_IMPORT');
      return {url,shortCircuit:true};
    },
    load(url,context,nextLoad){
      if(url.startsWith('node:')&&isBuiltin(url))return nextLoad(url,context);
      need(sources.has(url),'C_996_OWNER_UNSEALED_IMPORT');
      return {format:'module',source:sources.get(url),shortCircuit:true};
    },
  });
}

function classifierPins(original,continuation,sourceLockSha256,readySha256){
  const oldC={
    'owner.json':original.oldC,
    'PREPARED.json':original.PREPARED,
    'WORKFLOW_ENABLE_ATTEMPTED.json':original.WORKFLOW_ENABLE_ATTEMPTED,
    'BACKLOG_CLOSE_ATTEMPTED.json':original.BACKLOG_CLOSE_ATTEMPTED,
  };
  const install={'owner.json':original.installOwner,
    'RECOVERY_REQUIRED.json':original.installRecovery};
  return {oldC,install,continuationBeforeReady:continuation,
    readySha256,sourceLockSha256};
}
function phases(continuationId,manifest,reservationOwnerSha256,continuation,
  expected){
  return {continuationRequestId:continuationId,
    protectionBaseline:manifest.protectionBaseline??null,
    pins:{originalPins:manifest.originalPins,reservationOwnerSha256,
      classifierPins:classifierPins(manifest.originalPins,continuation,
        manifest.sourceLockSha256,expected.readySha256)}};
}

// This source deliberately exposes NO testOnly/write port. Only the real
// Windows operator, after owner consent and source readback, may call it.
export async function run996NativeOwnerCOnce({manifestCommitSha}={}){
  let phase='NO_WRITE';
  try{
    originalWindows();
    need(H40(manifestCommitSha),'C_996_OWNER_MANIFEST_COMMIT_REQUIRED');
    // No caller flag, test receipt or direct import can authorize a write.
    // The CLI verifies the builtins-only authentication source, installs the
    // pinned-byte loader, and independently reads exact human Owner consent.
    need(sealedOwnerEntry?.manifestCommitSha===manifestCommitSha&&
      sealedOwnerEntry.bootstrapSha256===TRUSTED_BOOTSTRAP_SHA256&&
      sealedOwnerEntry.operatorSha256===sha(safeFile(path.join(DIR,path.basename(SELF_REPO)),2_000_000)),
      'C_996_OWNER_PREIMPORT_AND_NATIVE_CAS_NOT_ATTESTED');
    const [{create996InstalledGhGetReadOnly},
      {create996ContinuationConsentEvidenceReader},
      {create996FourOriginalJobsReadOnlyReader}]=await Promise.all([
      import('./controller-996-c-installed-gh-get-readonly.mjs'),
      import('./controller-996-native-continuation-consent-reader.mjs'),
      import('./controller-996-original-four-jobs-readonly.mjs'),
    ]);
    const consentReader=create996ContinuationConsentEvidenceReader({
      githubReader:create996InstalledGhGetReadOnly()});
    const consent=await consentReader.readOnce({manifestCommitSha});
    need(consent?.consentCommentId===sealedOwnerEntry.ownerConsentCommentId&&
      consent.manifestSha256===sealedOwnerEntry.manifestSha256&&
      consent.operatorSha256===sealedOwnerEntry.operatorSha256&&
      consent.bootstrapSha256===sealedOwnerEntry.bootstrapSha256&&
      consent.sourceLockSha256===sealedOwnerEntry.sourceLockSha256&&
      consent.packageSha256===sealedOwnerEntry.packageSha256,
      'C_996_OWNER_EXACT_EXECUTION_CONSENT_CHANGED');
    let manifest;try{manifest=JSON.parse(consent.rawManifestBytes.toString('utf8'));}
    catch{need(false,'C_996_OWNER_CONSENT_MANIFEST_INVALID');}
    checkSourceBundle(manifest,manifestCommitSha);
    const jobs=await create996FourOriginalJobsReadOnlyReader({
      githubReader:create996InstalledGhGetReadOnly()}).readOnce();
    need(jobs?.status==='FOUR_ORIGINAL_JOBS_UNRESOLVED_GET_ONLY'&&
      jobs.originalIssueCount===4,
      'C_996_OWNER_ORIGINAL_JOBS_UNVERIFIED');
    const [{collect996OriginalCPrewriteReadOnly},
      {inspect996COriginalStageReadOnly},
      {plan996WindowsArchive}]=await Promise.all([
      import('./controller-996-c-original-prewrite-readonly.mjs'),
      import('./controller-996-c-original-stage-readonly.mjs'),
      import('./controller-996-windows-archive-adapter.mjs'),
    ]);
    const preflight=()=>{
      const r=collect996OriginalCPrewriteReadOnly({protectionBaseline:manifest.protectionBaseline??null});
      need(r.status==='C_ORIGINAL_PREWRITE_FILE_PINS_OBSERVED_ONLY'&&
        r.originalWindowsReadback===true&&r.filesReadTwice===10&&
        r.sourceBytesReadAgain===84&&r.oldOwnersObservedDead===true&&
        r.backlogReplayCount===0&&r.protectedR1ChecksPassed===14&&
        same(r.pins,manifest.originalPins),
        'C_996_OWNER_FRESH_ORIGINAL_PIN_DRIFT');
    };
    preflight();
    const plan=plan996WindowsArchive(manifest.continuationRequestId);
    need(plan.steps.length===3&&plan.steps[2].name==='install'&&
      plan.originalRequestId===REQ&&
      manifest.effects.includes(
        'CREATE_AND_PRESERVE_FIXED_C_RESERVATION_VIA_ATOMIC_PROPOSAL_MOVE'),
      'C_996_OWNER_ARCHIVE_PLAN_OR_EFFECT_INVALID');
    // Final read-only CAS before the FIRST operating-PC mutation.
    preflight();
    const id=manifest.continuationRequestId,nonce=randomUUID();
    need(UUID(id)&&UUID(nonce),'C_996_OWNER_ID_INVALID');
    const reservationName='controller-recovery-continuation-reservation';
    const proposalName=`controller-recovery-continuation-proposal-${id}`;
    const continuationName=`controller-recovery-continuation-${id}`;
    const fixed=path.join(LEASES,reservationName);
    const proposal=path.join(LEASES,proposalName);
    const continuation=path.join(LEASES,continuationName);
    safeLeaseDirectory('');
    need(absent(fixed)&&absent(proposal)&&absent(continuation),
      'C_996_OWNER_RESERVATION_COLLISION');
    // From here, any failure is STATE_UNKNOWN; NEVER retry or clean up.
    phase='RESERVATION_PROPOSAL';
    fs.mkdirSync(proposal);
    const reservationOwner={schema:'ZGMINI_996_C_FIXED_RESERVATION_OWNER_V1',
      continuationRequestId:id,originalRequestId:REQ,pid:process.pid,
      nonce,at:new Date().toISOString()};
    const reservationOwnerSha256=writeOnce(proposal,'owner.json',reservationOwner);
    moveNoReplace(proposal,fixed,{files:{'owner.json':reservationOwnerSha256},
      ownerMode:'LIVE_NEW',actorPid:process.pid,nonce});
    need(sha(safeFile(path.join(fixed,'owner.json'),16_384))===
      reservationOwnerSha256,'C_996_OWNER_RESERVATION_READBACK_CHANGED');
    phase='CONTINUATION_CLAIM';
    fs.mkdirSync(continuation);
    const at=new Date().toISOString(),claim={
      schema:'ZGMINI_996_CONTINUATION_CLAIM_V1',requestId:id,
      originalRequestId:REQ,pid:process.pid,nonce,at};
    const c={};
    c['owner.json']=writeOnce(continuation,'owner.json',claim);
    c['PREPARED.json']=writeOnce(continuation,'PREPARED.json',{
      schema:claim.schema,requestId:id,originalRequestId:REQ,
      ownerNonce:nonce,sourceLockSha256:manifest.sourceLockSha256,
      originalClaimSha256:manifest.originalPins.oldC,at});
    let readySha256='0'.repeat(64);
    const stage=(expectedPhase)=>{
      const r=inspect996COriginalStageReadOnly(phases(id,manifest,
        reservationOwnerSha256,c,{readySha256}));
      need(r.status==='C_STAGE_LIVE_INVENTORY_READ_ONLY'&&
        r.phase===expectedPhase&&r.originalWindowsReadback===true&&
        r.twiceIdentical===true&&r.sourceBytesVerified===true&&
        r.sourceFilesVerified===84&&r.fixedReservationOwnerObserved===true,
        'C_996_OWNER_LIVE_STAGE_CAS_UNKNOWN');
      return r;
    };
    stage('ORIGINAL_WITH_CONTINUATION_CLAIM_RESERVED');
    // Canonical install lease remains untouched until the FINAL move.
    phase='OLD_C_ARCHIVE';
    c['OLD_C_CLAIM_ARCHIVE_ATTEMPTED.json']=writeOnce(continuation,
      'OLD_C_CLAIM_ARCHIVE_ATTEMPTED.json',{
        schema:claim.schema,requestId:id,ownerNonce:nonce,
        oldClaimSha256:manifest.originalPins.oldC,
        at:new Date().toISOString()});
    stage('ORIGINAL_WITH_CONTINUATION_CLAIM_RESERVED');
    moveNoReplace(plan.steps[0].source,plan.steps[0].destination,{
      files:classifierPins(manifest.originalPins,c,
        manifest.sourceLockSha256,readySha256).oldC,
      ownerMode:'DEAD_OLD'});
    stage('AFTER_OLD_C_ARCHIVED_INSTALL_HELD');
    phase='READY_AND_CONTINUATION_ARCHIVE';
    readySha256=writeOnce(continuation,'READY_TO_RELEASE_INSTALL.json',{
      schema:'ZGMINI_996_CONTINUATION_READY_V1',
      name:'READY_TO_RELEASE_INSTALL',requestId:id,originalRequestId:REQ,
      ownerNonce:nonce,sourceLockSha256:manifest.sourceLockSha256,
      oldCArchiveOwnerSha256:manifest.originalPins.oldC,
      installOwnerSha256:manifest.originalPins.installOwner,
      installRecoverySha256:manifest.originalPins.installRecovery,
      finalReleasePending:true,at:new Date().toISOString(),
    });
    stage('AFTER_OLD_C_ARCHIVED_READY_NOT_YET_ARCHIVED');
    moveNoReplace(plan.steps[1].source,plan.steps[1].destination,{
      files:{...c,'READY_TO_RELEASE_INSTALL.json':readySha256},
      ownerMode:'LIVE_NEW',actorPid:process.pid,nonce});
    stage('AFTER_CONTINUATION_ARCHIVED_READY_INSTALL_HELD');
    phase='INSTALL_ARCHIVE_LAST';
    stage('AFTER_CONTINUATION_ARCHIVED_READY_INSTALL_HELD');
    // New independent GET reader; a deleted/edited/revoked/ambiguous Owner
    // comment after the earlier consent stops the final install move.
    const lastConsent=await create996ContinuationConsentEvidenceReader({
      githubReader:create996InstalledGhGetReadOnly()}).readOnce({
      manifestCommitSha});
    need(lastConsent?.status==='C_CONTINUATION_CONSENT_EVIDENCE_REVIEWED_ONLY'&&
      lastConsent.consentCommentId===consent.consentCommentId&&
      lastConsent.manifestSha256===consent.manifestSha256&&
      lastConsent.operatorSha256===consent.operatorSha256&&
      lastConsent.bootstrapSha256===consent.bootstrapSha256&&
      lastConsent.sourceLockSha256===consent.sourceLockSha256&&
      lastConsent.packageSha256===consent.packageSha256&&
      lastConsent.rawManifestBytes.equals(consent.rawManifestBytes),
    'C_996_OWNER_FINAL_OWNER_CONSENT_REVOKED_OR_CHANGED');
    checkSourceBundle(manifest,manifestCommitSha);
    stage('AFTER_CONTINUATION_ARCHIVED_READY_INSTALL_HELD');
    moveNoReplace(plan.steps[2].source,plan.steps[2].destination,{
      files:classifierPins(manifest.originalPins,c,
        manifest.sourceLockSha256,readySha256).install,
      ownerMode:'DEAD_INSTALL'});
    // FINAL move above is the last write. Everything below is read-only.
    phase='READONLY_POSTCHECK';
    const result=stage('AFTER_INSTALL_ARCHIVED');
    need(result.installBarrierRetained===false,
      'C_996_OWNER_INSTALL_POSTCHECK_UNKNOWN');
    return Object.freeze({
      schema:'ZGMINI_CONTROLLER_996_NATIVE_OWNER_C_RESULT_V1',
      status:'INTAKE_RECOVERED_ORIGINAL_INSTALL_ABORTED',
      code:'C_RECOVERY_EFFECTS_PERFORMED_NO_AUTOMATIC_JOB_REPLAY',
      sourceLocked:true,ownerConsentReadbackId:consent.consentCommentId,
      completedArchiveMoves:3,fixedReservationPreserved:true,
      originalInstallSucceeded:false,
      actualControllerSha:'badad9124157879d7a645b64f2768113d632355b',
      activeIntakeReadbackVerified:true,closedBacklogReadbackVerified:true,
      originalRequestRetries:0,workflowPuts:0,backlogWrites:0,
      issuePosts:0,automaticRetry:false,cleanupPerformed:false,
    });
  }catch(e){return stop(safeCode(e),phase);}
}

// Review is read-only. Execution is a separate explicit mode and accepts only
// the fixed authentication verifier, exact Owner comment and pinned imports.
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const [mode,manifestCommitSha]=process.argv.slice(2);
    try{
      need(process.argv.length===4&&['--verify-handoff','--execute-once'].includes(mode)&&H40(manifestCommitSha),'C_996_OWNER_REVIEW_ARGS_INVALID');
      const input=fs.readFileSync(0,'utf8');
      need(input.length<=16384,'C_996_OWNER_HANDOFF_SIZE');
      const claimed=JSON.parse(input);
      need(claimed?.fixtureOnly!==true&&claimed?.executionAuthorized===false&&
        claimed?.operatorStarted===false,'C_996_OWNER_HANDOFF_EVIDENCE_DRIFT');
      if(mode==='--execute-once'){
        originalWindows();
        need(claimed.bootstrapSha256===TRUSTED_BOOTSTRAP_SHA256,
          'C_996_OWNER_AUTHENTICATION_SOURCE_UNTRUSTED');
      }
      const imports=pin996ReviewImports(claimed);
      try{
      const {verify996CTrustedBootstrapReadOnly}=await import('./controller-996-c-native-trusted-bootstrap.mjs');
      const verified=verify996CTrustedBootstrapReadOnly({manifestCommitSha});
      const keys=['manifestCommitSha','manifestSha256','ownerConsentCommentId','operatorSha256',
        'bootstrapSha256','sourceLockSha256','packageSha256'];
      need(verified.status==='GIT_AND_LOCAL_BYTES_OBSERVED_ONLY'&&verified.fixtureOnly!==true&&
        verified.executionAuthorized===false&&verified.operatorStarted===false&&
        verified.manifestCommitSha===manifestCommitSha&&keys.every(key=>verified[key]===claimed?.[key])&&
        ['outerSha256','launcherSha256','helperSha256','nodeSha256'].every(key=>
          H64(verified.launchPins?.[key])&&verified.launchPins[key]===claimed?.launchPins?.[key]),
        'C_996_OWNER_HANDOFF_EVIDENCE_DRIFT');
      if(mode==='--execute-once'){
        sealedOwnerEntry=Object.freeze({...verified});
        try{
          const result=await run996NativeOwnerCOnce({manifestCommitSha});
          console.log(JSON.stringify(result));
          if(result.status!=='INTAKE_RECOVERED_ORIGINAL_INSTALL_ABORTED')process.exitCode=2;
        }finally{sealedOwnerEntry=null;}
      }else console.log(JSON.stringify({status:'OPERATOR_REVIEW_BOUNDARY_REACHED',
        code:'C_996_OWNER_PREIMPORT_AND_NATIVE_CAS_NOT_ATTESTED',executionAuthorized:false,
        originalPcWrites:0,manifestCommitSha,manifestSha256:verified.manifestSha256,
        ownerConsentCommentId:verified.ownerConsentCommentId}));
      }finally{imports.deregister();}
    }catch(e){
      console.log(JSON.stringify({status:'OPERATOR_REVIEW_NO_GO',
        code:/^C_996_OWNER_[A-Z0-9_]+$/.test(e?.code??'')?e.code:'C_996_OWNER_HANDOFF_UNVERIFIED',
        executionAuthorized:false,originalPcWrites:0}));
      process.exitCode=2;
    }
}
